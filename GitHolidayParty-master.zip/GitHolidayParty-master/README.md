# GitHolidayParty
A git presentation for GDGSudbury's annual holiday party
